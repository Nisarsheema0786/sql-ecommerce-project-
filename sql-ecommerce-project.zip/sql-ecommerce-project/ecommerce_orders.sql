
-- E-commerce Orders SQL Project

-- Customers table
CREATE TABLE customers1(
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(30)
);

-- Orders table
CREATE TABLE orders(
    orders_id INT,
    customer_id INT,
    product_id INT
);

-- Products table
CREATE TABLE products1(
    product_id INT,
    product_name VARCHAR(20)
);

-- Insert sample data
INSERT INTO customers1 VALUES (1, 'naaz'), (2, 'ali'), (3, 'shahanaz');
INSERT INTO orders VALUES (101, 1, 1001), (102, 1, 1002), (103, 2, 1003);
INSERT INTO products1 VALUES (1001, 'laptop'), (1002, 'phone'), (1003, 'tablet');

-- Join queries
SELECT customers1.customer_name, products1.product_name
FROM customers1
JOIN orders ON customers1.customer_id = orders.customer_id
JOIN products1 ON orders.product_id = products1.product_id;

-- Customers who didn't order anything
SELECT c.customer_name
FROM customers1 c
LEFT JOIN orders o ON c.customer_id = o.customer_id
WHERE o.orders_id IS NULL;

-- Product-wise customer count
SELECT p.product_name, COUNT(o.customer_id) AS customer_count
FROM products1 p
LEFT JOIN orders o ON p.product_id = o.product_id
GROUP BY p.product_name;
